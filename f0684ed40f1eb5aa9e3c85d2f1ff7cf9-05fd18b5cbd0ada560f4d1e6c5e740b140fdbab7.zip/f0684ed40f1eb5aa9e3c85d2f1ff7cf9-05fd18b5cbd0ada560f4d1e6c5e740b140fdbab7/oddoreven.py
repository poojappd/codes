x=int(input("enter the number to find odd or even"))
if(x>0):
  if(x%2==0):
   print("\nevennumber")
  else:
   print("\nodd number")
else:
  print("\ninvalid")